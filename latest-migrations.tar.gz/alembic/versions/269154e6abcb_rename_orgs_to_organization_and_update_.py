"""rename orgs to organization and update columns

Revision ID: 269154e6abcb
Revises: 98c4340e396c
Create Date: 2025-08-26 08:23:28.109366

"""

from __future__ import annotations

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision: str = "269154e6abcb"
down_revision: Union[str, None] = "98c4340e396c"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.drop_table("orgs")
    op.drop_table("users")

    op.create_table(
        "users",
        sa.Column("id", sa.UUID(), primary_key=True, default=sa.text("gen_random_uuid()"), nullable=False),
        sa.Column("email", sa.String(255), nullable=False, unique=True, index=True),
        sa.Column("org_id", sa.UUID(), nullable=True),  # FK will be added later
        sa.Column("role", sa.String(50), default="admin", nullable=False),
    )

    op.create_table(
        "organizations",
        sa.Column("id", sa.UUID(), primary_key=True, default=sa.text("gen_random_uuid()"), nullable=False),
        sa.Column("owner_id", sa.UUID(), nullable=False),  # FK will be added later
        sa.Column("name", sa.String(255), nullable=False, unique=True),
        sa.Column("address", sa.UUID(), nullable=True),
        sa.Column("website", sa.String(255), nullable=True),
        sa.Column("contact", sa.UUID(), nullable=True),
        sa.Column("created_at", sa.DateTime(), server_default=sa.text("now()"), nullable=False),
    )

    op.create_foreign_key(
        "users_org_id_fkey",
        "users", "organizations",
        ["org_id"], ["id"],
    )

    op.create_foreign_key(
        "organizations_owner_id_fkey",
        "organizations", "users",
        ["owner_id"], ["id"],
    )

def downgrade() -> None:
    op.drop_table("organizations")
    op.drop_table("users")
    op.create_table(
        "users",
        sa.Column("id", sa.INTEGER(), primary_key=True, autoincrement=True, nullable=False),
        sa.Column("email", sa.String(length=255), nullable=False, unique=True, index=True),
        sa.Column("gid", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("account", sa.BOOLEAN(), server_default=sa.text("true"), nullable=False),
        sa.Column("role", sa.String(length=50), nullable=False, server_default="admin"),
    )
    op.create_index(op.f("ix_users_gid"), "users", ["gid"], unique=False)

    op.create_table(
        "orgs",
        sa.Column("org_id", sa.INTEGER(), primary_key=True, autoincrement=True, nullable=False),
        sa.Column("gid", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("owner_id", sa.INTEGER(), nullable=False),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("address", sa.String(length=255), nullable=True),
        sa.Column("website", sa.String(length=255), nullable=True),
        sa.Column("contact", sa.String(length=50), nullable=True),
        sa.Column("created_at", postgresql.TIMESTAMP(), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["owner_id"], ["users.id"], name=op.f("orgs_owner_id_fkey")),
        sa.UniqueConstraint("gid", name=op.f("orgs_gid_key")),
        sa.UniqueConstraint("name", name=op.f("orgs_name_key")),
    )
