"""user_role_table_creation_2

Revision ID: 090f6d18782e
Revises: 607fc01a2e5f
Create Date: 2025-09-04 08:28:06.785309

"""
from __future__ import annotations

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '090f6d18782e'
down_revision: Union[str, None] = '607fc01a2e5f'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table('user_roles',
    sa.Column('userid', sa.UUID(), nullable=False),
    sa.Column('accounts', sa.ARRAY(sa.String()), nullable=False),
    sa.Column('opportunities', sa.ARRAY(sa.String()), nullable=False),
    sa.Column('proposals', sa.ARRAY(sa.String()), nullable=False),
    sa.ForeignKeyConstraint(['userid'], ['users.id'], ),
    sa.PrimaryKeyConstraint('userid')
    )
    op.create_index(op.f('ix_user_roles_userid'), 'user_roles', ['userid'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_user_roles_userid'), table_name='user_roles')
    op.drop_table('user_roles')


