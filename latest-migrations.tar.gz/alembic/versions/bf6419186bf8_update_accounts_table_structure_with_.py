"""update_accounts_table_structure_with_uuid_references

Revision ID: bf6419186bf8
Revises: c3c200e56056
Create Date: 2025-08-29 15:08:42.720158

"""
from __future__ import annotations

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = 'bf6419186bf8'
down_revision: Union[str, None] = 'c3c200e56056'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass


