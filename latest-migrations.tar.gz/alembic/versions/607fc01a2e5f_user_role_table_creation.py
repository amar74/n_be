"""user_role_table_creation

Revision ID: 607fc01a2e5f
Revises: e0f52551bb55
Create Date: 2025-09-04 08:24:14.173372

"""
from __future__ import annotations

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '607fc01a2e5f'
down_revision: Union[str, None] = 'e0f52551bb55'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass


