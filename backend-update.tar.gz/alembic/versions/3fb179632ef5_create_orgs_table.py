"""create orgs table

Revision ID: 3fb179632ef5
Revises: c9c13f89943b
Create Date: 2025-08-22 18:43:03.328672

"""
from __future__ import annotations

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '3fb179632ef5'
down_revision: Union[str, None] = 'c9c13f89943b'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'orgs',
        sa.Column('org_id', sa.Integer(), nullable=False),
        sa.Column('gid', sa.UUID(as_uuid=True), nullable=False),
        sa.Column('owner_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=False),

        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('address', sa.String(length=255), nullable=True),
        sa.Column('website', sa.String(length=255), nullable=True),
        sa.Column('contact', sa.String(length=50), nullable=True),

        sa.Column('created_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.PrimaryKeyConstraint('org_id'),
        sa.UniqueConstraint('gid'),
        sa.UniqueConstraint('name')
    )


def downgrade() -> None:
    op.drop_table('orgs')
    pass


