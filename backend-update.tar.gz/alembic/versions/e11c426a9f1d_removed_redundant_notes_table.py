"""removed redundant notes table

Revision ID: e11c426a9f1d
Revises: c1e315f206fa
Create Date: 2025-09-12 13:31:09.191998

"""
from __future__ import annotations

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = 'e11c426a9f1d'
down_revision: Union[str, None] = 'c1e315f206fa'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.drop_index(op.f('ix_notes_id'), table_name='notes')
    op.drop_index(op.f('ix_notes_meeting_title'), table_name='notes')
    op.drop_table('notes')


def downgrade() -> None:
    op.create_table('notes',
    sa.Column('id', sa.UUID(), autoincrement=False, nullable=False),
    sa.Column('meeting_title', sa.VARCHAR(length=255), autoincrement=False, nullable=False),
    sa.Column('meeting_datetime', postgresql.TIMESTAMP(), autoincrement=False, nullable=False),
    sa.Column('meeting_notes', sa.TEXT(), autoincrement=False, nullable=False),
    sa.Column('created_at', postgresql.TIMESTAMP(), server_default=sa.text('now()'), autoincrement=False, nullable=False),
    sa.Column('updated_at', postgresql.TIMESTAMP(), autoincrement=False, nullable=True),
    sa.Column('org_id', sa.UUID(), autoincrement=False, nullable=False),
    sa.Column('created_by', sa.UUID(), autoincrement=False, nullable=False),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('notes_created_by_fkey')),
    sa.ForeignKeyConstraint(['org_id'], ['organizations.id'], name=op.f('notes_org_id_fkey')),
    sa.PrimaryKeyConstraint('id', name=op.f('notes_pkey'))
    )
    op.create_index(op.f('ix_notes_meeting_title'), 'notes', ['meeting_title'], unique=False)
    op.create_index(op.f('ix_notes_id'), 'notes', ['id'], unique=True)


