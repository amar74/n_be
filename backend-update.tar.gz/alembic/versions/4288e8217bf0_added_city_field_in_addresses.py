"""added city field in addresses

Revision ID: 4288e8217bf0
Revises: 07da41c7db8d
Create Date: 2025-09-12 02:22:08.919387

"""
from __future__ import annotations

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '4288e8217bf0'
down_revision: Union[str, None] = '07da41c7db8d'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.drop_constraint(op.f('accounts_org_id_fkey'), 'accounts', type_='foreignkey')
    op.create_foreign_key(None, 'accounts', 'organizations', ['org_id'], ['id'])
    op.add_column('address', sa.Column('city', sa.String(length=255), nullable=True))
    op.alter_column('contacts', 'title',
               existing_type=sa.VARCHAR(length=64),
               type_=sa.String(length=100),
               existing_nullable=True)
    op.drop_constraint(op.f('contacts_account_id_fkey'), 'contacts', type_='foreignkey')
    op.drop_constraint(op.f('contacts_org_id_fkey'), 'contacts', type_='foreignkey')
    op.create_foreign_key(None, 'contacts', 'organizations', ['org_id'], ['id'], ondelete='CASCADE')
    op.create_foreign_key(None, 'contacts', 'accounts', ['account_id'], ['account_id'], ondelete='CASCADE')


def downgrade() -> None:
    op.drop_constraint(None, 'contacts', type_='foreignkey')
    op.drop_constraint(None, 'contacts', type_='foreignkey')
    op.create_foreign_key(op.f('contacts_org_id_fkey'), 'contacts', 'organizations', ['org_id'], ['id'])
    op.create_foreign_key(op.f('contacts_account_id_fkey'), 'contacts', 'accounts', ['account_id'], ['account_id'])
    op.alter_column('contacts', 'title',
               existing_type=sa.String(length=100),
               type_=sa.VARCHAR(length=64),
               existing_nullable=True)
    op.drop_column('address', 'city')
    op.drop_constraint(None, 'accounts', type_='foreignkey')
    op.create_foreign_key(op.f('accounts_org_id_fkey'), 'accounts', 'organizations', ['org_id'], ['id'], ondelete='CASCADE')


