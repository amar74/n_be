"""fix account address contact relationships

Revision ID: 4639c8c5af9a
Revises: 21c72d6b7d1a
Create Date: 2025-08-28 15:21:53.728554

"""
from __future__ import annotations

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '4639c8c5af9a'
down_revision: Union[str, None] = '21c72d6b7d1a'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table('accounts',
    sa.Column('account_id', sa.UUID(), nullable=False),
    sa.Column('company_website', sa.String(length=255), nullable=True),
    sa.Column('client_name', sa.String(length=255), nullable=False),
    sa.Column('client_type', sa.Enum('tier_1', 'tier_2', 'tier_3', name='clienttype'), nullable=False),
    sa.Column('market_sector', sa.String(length=255), nullable=True),
    sa.Column('notes', sa.String(length=1024), nullable=True),
    sa.Column('total_value', sa.Numeric(), nullable=True),
    sa.Column('ai_health_score', sa.Numeric(), nullable=True),
    sa.Column('opportunities', sa.Integer(), nullable=True),
    sa.Column('last_contact', sa.DateTime(), nullable=True),
    sa.Column('created_at', sa.DateTime(), server_default=sa.text('now()'), nullable=True),
    sa.Column('updated_at', sa.DateTime(), nullable=True),
    sa.Column('client_address_id', sa.UUID(), nullable=True),
    sa.Column('primary_contact_id', sa.UUID(), nullable=True),
    sa.ForeignKeyConstraint(['client_address_id'], ['address.id'], ),
    sa.ForeignKeyConstraint(['primary_contact_id'], ['contacts.id'], ),
    sa.PrimaryKeyConstraint('account_id')
    )
    op.create_index(op.f('ix_accounts_account_id'), 'accounts', ['account_id'], unique=True)
    op.create_index(op.f('ix_address_id'), 'address', ['id'], unique=True)
    op.drop_constraint(op.f('address_org_id_fkey'), 'address', type_='foreignkey')
    op.create_foreign_key(None, 'address', 'organizations', ['org_id'], ['id'])
    op.add_column('contacts', sa.Column('account_id', sa.UUID(), nullable=True))
    op.add_column('contacts', sa.Column('name', sa.String(length=255), nullable=True))
    op.add_column('contacts', sa.Column('title', sa.String(length=64), nullable=True))
    op.alter_column('contacts', 'email',
               existing_type=sa.VARCHAR(length=100),
               type_=sa.String(length=255),
               existing_nullable=True)
    op.create_index(op.f('ix_contacts_id'), 'contacts', ['id'], unique=False)
    op.drop_constraint(op.f('contact_org_id_fkey'), 'contacts', type_='foreignkey')
    op.create_foreign_key(None, 'contacts', 'organizations', ['org_id'], ['id'])
    op.create_foreign_key(None, 'contacts', 'accounts', ['account_id'], ['account_id'])
    op.alter_column('invites', 'org_id',
               existing_type=sa.UUID(),
               nullable=True)
    op.create_index(op.f('ix_invites_id'), 'invites', ['id'], unique=True)
    op.create_unique_constraint(None, 'invites', ['token'])
    op.create_foreign_key(None, 'invites', 'users', ['invited_by'], ['id'])
    op.create_foreign_key(None, 'invites', 'organizations', ['org_id'], ['id'])
    op.drop_constraint(op.f('organizations_name_key'), 'organizations', type_='unique')
    op.create_index(op.f('ix_organizations_id'), 'organizations', ['id'], unique=True)
    op.create_index(op.f('ix_organizations_name'), 'organizations', ['name'], unique=True)
    op.create_index(op.f('ix_users_id'), 'users', ['id'], unique=False)
    op.drop_constraint(op.f('users_org_id_fkey'), 'users', type_='foreignkey')
    op.create_foreign_key(None, 'users', 'organizations', ['org_id'], ['id'])


def downgrade() -> None:
    op.drop_constraint(None, 'users', type_='foreignkey')
    op.create_foreign_key(op.f('users_org_id_fkey'), 'users', 'organizations', ['org_id'], ['id'], ondelete='CASCADE')
    op.drop_index(op.f('ix_users_id'), table_name='users')
    op.drop_index(op.f('ix_organizations_name'), table_name='organizations')
    op.drop_index(op.f('ix_organizations_id'), table_name='organizations')
    op.create_unique_constraint(op.f('organizations_name_key'), 'organizations', ['name'], postgresql_nulls_not_distinct=False)
    op.drop_constraint(None, 'invites', type_='foreignkey')
    op.drop_constraint(None, 'invites', type_='foreignkey')
    op.drop_constraint(None, 'invites', type_='unique')
    op.drop_index(op.f('ix_invites_id'), table_name='invites')
    op.alter_column('invites', 'org_id',
               existing_type=sa.UUID(),
               nullable=False)
    op.drop_constraint(None, 'contacts', type_='foreignkey')
    op.drop_constraint(None, 'contacts', type_='foreignkey')
    op.create_foreign_key(op.f('contact_org_id_fkey'), 'contacts', 'organizations', ['org_id'], ['id'], ondelete='CASCADE')
    op.drop_index(op.f('ix_contacts_id'), table_name='contacts')
    op.alter_column('contacts', 'email',
               existing_type=sa.String(length=255),
               type_=sa.VARCHAR(length=100),
               existing_nullable=True)
    op.drop_column('contacts', 'title')
    op.drop_column('contacts', 'name')
    op.drop_column('contacts', 'account_id')
    op.drop_constraint(None, 'address', type_='foreignkey')
    op.create_foreign_key(op.f('address_org_id_fkey'), 'address', 'organizations', ['org_id'], ['id'], ondelete='CASCADE')
    op.drop_index(op.f('ix_address_id'), table_name='address')
    op.drop_index(op.f('ix_accounts_account_id'), table_name='accounts')
    op.drop_table('accounts')


