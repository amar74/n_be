"""add account boolean to users

Revision ID: 98c4340e396c
Revises: 3fb179632ef5
Create Date: 2025-08-23 03:19:14.682031

"""

from __future__ import annotations

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision: str = "98c4340e396c"
down_revision: Union[str, None] = "3fb179632ef5"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "users",
        sa.Column("account", sa.Boolean(), nullable=False, server_default=sa.true()),
    )


def downgrade() -> None:
    op.drop_column("users", "account")
    op.create_table(
        "orgs",
        sa.Column("org_id", sa.INTEGER(), autoincrement=True, nullable=False),
        sa.Column("gid", sa.UUID(), autoincrement=False, nullable=False),
        sa.Column("owner_id", sa.INTEGER(), autoincrement=False, nullable=False),
        sa.Column("name", sa.VARCHAR(length=255), autoincrement=False, nullable=False),
        sa.Column(
            "address", sa.VARCHAR(length=255), autoincrement=False, nullable=True
        ),
        sa.Column(
            "website", sa.VARCHAR(length=255), autoincrement=False, nullable=True
        ),
        sa.Column("contact", sa.VARCHAR(length=50), autoincrement=False, nullable=True),
        sa.Column(
            "created_at",
            postgresql.TIMESTAMP(),
            server_default=sa.text("now()"),
            autoincrement=False,
            nullable=False,
        ),
        sa.ForeignKeyConstraint(
            ["owner_id"], ["users.id"], name=op.f("orgs_owner_id_fkey")
        ),
        sa.PrimaryKeyConstraint("org_id", name=op.f("orgs_pkey")),
        sa.UniqueConstraint(
            "gid",
            name=op.f("orgs_gid_key"),
            postgresql_include=[],
            postgresql_nulls_not_distinct=False,
        ),
        sa.UniqueConstraint(
            "name",
            name=op.f("orgs_name_key"),
            postgresql_include=[],
            postgresql_nulls_not_distinct=False,
        ),
    )
