## Scope

These rules always apply to the `megapolis-api` backend. They encode the conventions from `Development.md` so AI edits follow the project's standards.

## Tech and Structure

- **Stack**: FastAPI, SQLAlchemy 2.0 (async), Alembic, Pydantic v2, Loguru
- **Entry**: `app/main.py` with CORS; routers included from `app/router.py`
- **DB**: Transactional Postgres via `app/db/session.py` (`get_request_transaction` provides the current request-scoped transaction; on errors the transaction is rolled back)
- **Models**: `app/models/*` extending `app.db.base.Base`
- **Schemas**: `app/schemas/*` with `Config.from_attributes = True`
- **Services**: `app/services/*` with async functions (or a small coordinator class if orchestration is required)
- **Routes**: `app/routes/*` (keep thin); included from `app/router.py`
- **Logging**: `from app.utils.logger import logger`
- **Auth**: JWT via dependency `app/dependencies/user_auth.py#get_current_user` (create if missing)

### Key Folder Explanations

- **app/main.py**: Entry point for the FastAPI application; configures CORS and mounts the `api_router`.
- **app/router.py**: Central router aggregator; includes all feature routers (one per domain).
- **app/routes/**: Feature HTTP endpoints; thin controllers that validate inputs and call services.
- **app/services/**: Business logic; async functions that orchestrate model calls and domain workflows.
- **app/models/**: SQLAlchemy ORM models; define tables and add convenience class/instance methods.
- **app/schemas/**: Pydantic v2 request/response models; responses set `from_attributes = True`.
- **app/db/**: Database base (`base.py`) and session factory (`session.py` with `get_db`).
- **app/utils/**: Shared utilities such as Loguru `logger` and small helpers.
- **app/dependencies/**: FastAPI dependencies (e.g., `user_auth.py#get_current_user`).
- **alembic/**: Database migration environment and versions.
- **manage.py**: Typer CLI for running the server and managing Alembic migrations.
- **pyproject.toml**: Poetry configuration for dependencies and tooling.

## Ground Rules

- **No tests unless requested**: Avoid adding tests unless explicitly asked, to keep scope focused.
- **Thin endpoints**: Keep routes minimal and delegate logic to services to maintain separation of concerns.
- **Prefer async end-to-end**: Use async I/O in routes, services, and DB to improve throughput.
- **Guard clauses and early returns**: Reduce nesting and improve readability by handling edge cases upfront.
- **Use Loguru, not print**: Leverage `logger` for structured logs; never log secrets or full tokens.
- **Return schemas, not ORM**: Endpoints should return Pydantic models or sanitized dicts, not ORM instances.
- **Run via Poetry**: Use `poetry run python manage.py ...` for server and migrations to ensure env parity.
- **Functional services; coordinate when needed**: Prefer functions. If multi-step orchestration is necessary, introduce a small coordinator and events.

## Commands

```bash
poetry run python manage.py run --host 0.0.0.0 --port 8000 --reload
poetry run python manage.py migrate -m "add <feature>"
poetry run python manage.py upgrade
poetry run python manage.py downgrade -1
poetry run python manage.py initdb
```

## Database Sessions

- **Always use `get_request_transaction()`**: Access the request-scoped transaction anywhere; do not introduce alternative patterns.

```python
from app.db.session import get_request_transaction
from app.models.user import User
from sqlalchemy import select

async def job():
    db = get_request_transaction()
    await db.execute(select(User).where(User.id == 1))
```

## Environment Variables

- **Access via `app.environment`**: Import `from app import environment` and read `environment.<VARIABLE_NAME>`.
- **Create if missing**: If `app/environment.py` is absent, create it and export from `app/__init__.py`.

```python
from app import environment

DATABASE_URL = environment.DATABASE_URL
JWT_SECRET_KEY = environment.JWT_SECRET_KEY
ENVIRONMENT = environment.ENVIRONMENT
```

## Authentication

- Use a dependency `get_current_user` from `app/dependencies/user_auth.py`. You can get the current user from the request context using `get_current_user` dependency.

```python
@app.get("/me")
async def get_me(user: User = Depends(get_current_user)):
    return user
```

## Error Handling

- **Raise `MegapolisHTTPException` in services**: Centralize client-facing errors; translate to HTTP at route boundaries.

```python
from app.utils.exceptions import MegapolisHTTPException

raise MegapolisHTTPException(status_code=400, message="Name already exists", metadata={"name": payload.name})
```

## Logging

- **Log with Loguru**: `from app.utils.logger import logger`; use `info`, `debug` (no secrets), `warning`, `error` appropriately.

## Models

- Place models in `app/models/<feature>.py` extending `Base`.
- Provide class/instance methods. Access the current request transaction inside model methods using `get_request_transaction`.

```python
from sqlalchemy import String, select
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional
from app.db.base import Base
from app.db.session import get_request_transaction

class Widget(Base):
    __tablename__ = "widgets"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, index=True)

    @classmethod
    async def create(cls, name: str) -> "Widget":
        db = get_request_transaction()
        inst = cls(name=name)
        db.add(inst)
        await db.flush()
        await db.refresh(inst)
        return inst

    @classmethod
    async def get_by_id(cls, widget_id: int) -> Optional["Widget"]:
        db = get_request_transaction()
        res = await db.execute(select(cls).where(cls.id == widget_id))
        return res.scalar_one_or_none()
```

## Schemas (Pydantic v2)

- Put request/response models in `app/schemas/<feature>.py` and set `from_attributes = True` for response models.

```python
from pydantic import BaseModel

class WidgetCreateRequest(BaseModel):
    name: str

class WidgetResponse(BaseModel):
    id: int
    name: str

    class Config:
        model_config = {"from_attributes": True}
```

## Services

- Keep services small and functional by default.
- Log major events and raise `MegapolisHTTPException` for client-visible errors.

```python
from app.utils.exceptions import MegapolisHTTPException
from app.models.widget import Widget
from app.schemas.widget import WidgetCreateRequest
from app.utils.logger import logger

async def create_widget(payload: WidgetCreateRequest):
    # Replace with real uniqueness check
    existing = await Widget.get_by_id(1)
    if existing and getattr(existing, "name", None) == payload.name:
        raise MegapolisHTTPException(status_code=400, message="Name already exists", metadata={"name": payload.name})
    logger.info("Creating widget")
    return await Widget.create(payload.name)
```

## Routes

- One `APIRouter` per domain in `app/routes/<feature>.py`. Return Pydantic models. Use auth dependency where needed.

```python
from fastapi import APIRouter, Depends
from app.schemas.widget import WidgetCreateRequest, WidgetResponse
from app.services.widget import create_widget
from app.dependencies.user_auth import get_current_user
from app.utils.logger import logger

router = APIRouter(prefix="/widgets", tags=["widgets"])

@router.post("/", response_model=WidgetResponse, status_code=201)
async def create_widget_route(payload: WidgetCreateRequest, user = Depends(get_current_user)) -> WidgetResponse:
    logger.info("POST /widgets")
    widget = await create_widget(payload)
    return WidgetResponse.model_validate(widget)
```

## Router Registration

- Include feature routers from `app/router.py`.

```python
from fastapi import APIRouter
from app.routes.widget import router as widget_router

api_router = APIRouter()
api_router.include_router(widget_router)
```

## Migrations

- When models change, generate and apply Alembic revisions via the CLI commands above.

## Prohibited / Cautions

- **No blocking code in handlers**: Avoid sync DB engines/sessions and blocking calls.
- **No `print` statements**: Always use structured logging with Loguru.
- **No raw ORM responses**: Convert to Pydantic models or sanitized dicts before returning.
- **No tests unless requested**: Only add tests when explicitly asked.

## Feature Workflow (Checklist)

1. Plan the model and API shapes (requests/responses, validations).
2. Add/modify SQLAlchemy models under `app/models/*`.
3. Run migrations with `poetry run python manage.py migrate -m "..."` and upgrade.
4. Add Pydantic schemas under `app/schemas/*` with `from_attributes = True`.
5. Implement service functions under `app/services/*` using async patterns and raising `MegapolisHTTPException` on errors.
6. Add routes under `app/routes/*` that call services, use `get_current_user` when needed, and return schemas.
7. Register the router in `app/router.py`.
8. Add logging at key points; validate inputs; avoid deep nesting.

## Code rules
- **Use `logger`, not `print`**: Centralized, structured logs; easier to filter and ship.
- **Use async/await correctly**: Non-blocking I/O ensures scalability under load.
- **Keep formatting consistent**: Follow existing style; avoid unrelated reformatting.
- **Type-annotate code**: Improve readability and tooling support with explicit hints.
- **One router per domain**: Keeps modules cohesive and routing discoverable.
- **Consistent names**: Use clear, predictable endpoint and parameter names.
- **Guard clauses first**: Handle invalid inputs early to simplify control flow.
- **Return early**: Reduce nesting and make happy-path obvious.
- **Validate inputs upfront**: Ensure correctness before performing side effects.

### Python Best Practices

- **Add type annotations**: All public functions and endpoints should be fully typed.
- **Follow PEP 8**: Maintain consistent, idiomatic Python formatting and naming.
- **Prefer small, reusable functions**: Decompose complex logic into testable units.
- **Read from environment**: Keep secrets/config in env; never hardcode sensitive values.
- **Return early**: Flatten control flow and highlight the happy path.
- **Separate API vs core**: Keep HTTP concerns in `app/routes`; move business logic to `app/services` (and a core library if introduced).
- **Functional API code**: Prefer pure functions and avoid side effects in API layer.
- **OOP for non-API code**: Use classes where appropriate in models, schemas, or orchestration.
- **Limit function arguments**: If >3–4 args, consider a data container (Pydantic model preferred).
- **Use async/await across I/O**: Ensure end-to-end non-blocking flows.
- **Avoid relative imports**: Use absolute imports for clarity and tooling support.
